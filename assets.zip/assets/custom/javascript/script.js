
//d�finition d'une "classe" laboratoire
function labo(numero,nom,responsable,sujet,adresse){
	this.numero=numero;
	this.nom=nom;
	this.responsable=responsable;
	this.sujet=sujet;
	this.adresse=adresse;
	this.i=0;
	
	this.gallerie=new Array(10); // chemins des photos
	
	this.ajouterPhoto=function(path) {
		if (this.i>=this.gallerie.length)
			return -1;
		this.gallerie[this.i]=path;
		this.i++;
	}
	this.definirSon=function(path) {
	this.son=path
	}
}





//initialisation



$(document).ready(function(){

	//liste des laboratoires
	
	liste_labos=new Array(12);
	liste_labos[0]=new labo(0,"INTRO","","L'histoire du Campus","");
	liste_labos[0].ajouterPhoto("../images/looking-otter.jpg");
	liste_labos[0].definirSon("../sounds/bird1.wav");
	liste_labos[1]=new labo(1,"Labo test","Inconnu","voyage dans le temps","");
	liste_labos[1].ajouterPhoto("../images/youpi_matin.png");
	
	
	$("#divcarte").html("<img src='../images/map_temp.png' id='carte'>");
	
	initialiserContenu();
	
});

function initialiserContenu() {
	var j=0;
	var k=0;
	for(k=0;k<1;k++) {
		$("#divcontenu").append("<div class='row-fluid divcontenu2'>");
		for (j=0;j<=1;j++) 
			
			$("#divcontenu").append("<div class='span2' onclick='afficherLabo("+liste_labos[j].numero+")'> <img src='"+liste_labos[j].gallerie[0]+"' class='photopres'></div> \
			<div class='span3' onclick='afficherLabo("+liste_labos[j].numero+")'> <p>"+liste_labos[j].nom+"</p><p> "+liste_labos[j].responsable+"</p><p>"+liste_labos[j].sujet+" </div>");
		$("#divcontenu").append("</div>"); 
		}
	contenuInitial=$("#divcontenu").html();
}

function reinitialiserContenu() {
	$("#divcontenu").fadeOut();
	setTimeout("$('#divcontenu').html(contenuInitial);",500);
	$("#divcontenu").fadeIn();
}
function afficherLabo(numero) {
	
	$("#divcontenu").fadeOut();
	setTimeout(genererContenu,500,numero);
	$("#divcontenu").fadeIn();
}

/*$("audio").mediaelementplayer({
  alwaysShowControls: true
});*/


function getPhoneGapPath() {

    var path = window.location.pathname;
    path = path.substr( path, path.length - 10 );
    return 'file://' + path;

};

function genererContenu(numero) {
	
	//var snd = new Media( getPhoneGapPath() + '../sounds/bird1.wav' );
	$("#divcontenu").html("<div class='row-fluid divcontenu2'>");
		$("#divcontenu").append("<div class='span5'> \
			<p> ESCALE "+numero+": "+liste_labos[numero].nom+"</p> \
			<p> <img src='../icons/icon_photo.png' class='iconContenu'> Les photos du labo</p> \
			<p> <audio controls='controls'> <source src='"+liste_labos[numero].son+"'> </audio> </p>\
		</div>\
		<div class='span6'>\
			<p><span><img src='../icons/icon_flag.png' class='iconContenu'></span><span> Poser un drapeau</span></p>\
			<div class='row-fluid'>\
				<div class='span6'> <img src='"+liste_labos[numero].gallerie[0]+"' class='photopres'></div>\
				<div class='span6'> <p>"+liste_labos[numero].nom+"</p><p> "+liste_labos[numero].responsable+"</p><p>"+liste_labos[numero].sujet+" </p></div>\
			</div>\
		</div>\
	</div>\
			");
		
		
}
 